# Mishary Online Quran Academy — Production Foundation

Real Next.js + PostgreSQL application foundation.

## Setup
1. Install Node.js 20+ and PostgreSQL.
2. `npm install`
3. Copy `.env.example` to `.env` and set `DATABASE_URL` and a strong `NEXTAUTH_SECRET`.
4. `npx prisma generate`
5. `npx prisma db push`
6. `npm run db:seed`
7. `npm run dev`

Seed admin/tutor password is `ChangeThisPassword123!`. Change it before deployment.

The application includes database-backed users, roles, tutor profiles, courses, tutor applications, secure password hashing, NextAuth login, student dashboard and conflict-checked class booking.

For public launch, connect your real payment provider, video provider, email/WhatsApp services, configure HTTPS/domain, backups and monitoring. Never expose secret API keys in client code.

## Included platform modules
- Public marketing site, courses, pricing, tutor directory and profiles
- Student registration, login and protected dashboard
- Tutor application and admin approval workflow
- Tutor dashboard with scheduled classes
- Booking conflict prevention
- Live classroom route using Jitsi Meet room per booking
- Admin dashboard, application review and booking oversight
- Database-backed payment records and Stripe integration entry point
- Reviews/messages/payment models ready in Prisma
- Responsive mobile/desktop design
- All content is file/database driven rather than hard-coded into browser storage

### Important production connections
Real card payments require your Stripe account and webhook secrets. Real email/WhatsApp notifications require your provider credentials. Live classes use Jitsi by default; a paid provider can be swapped in. Before public launch set HTTPS, strong secrets, database backups, rate limiting, CAPTCHA/anti-spam and transactional email.
