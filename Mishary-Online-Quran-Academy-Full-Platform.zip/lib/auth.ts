import {getServerSession,NextAuthOptions} from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import {prisma} from "./prisma";
export const authOptions:NextAuthOptions={session:{strategy:"jwt"},providers:[CredentialsProvider({name:"Credentials",credentials:{email:{},password:{}},async authorize(c){if(!c?.email||!c?.password)return null;const u=await prisma.user.findUnique({where:{email:c.email}});if(!u||!(await bcrypt.compare(c.password,u.passwordHash)))return null;return {id:u.id,name:u.name,email:u.email,role:u.role};}})],callbacks:{async jwt({token,user}){if(user)(token as any).role=(user as any).role;return token},async session({session,token}){if(session.user){(session.user as any).id=token.sub;(session.user as any).role=(token as any).role}return session}},pages:{signIn:"/login"}};
export async function requireSession(){const s=await getServerSession(authOptions);if(!s?.user)throw new Error("UNAUTHORIZED");return s;}